---
name: "JG Inmobiliaria Design System"
description: "Sistema de diseño elegante y contemporáneo para la comercialización inmobiliaria premium en Medellín y Bogotá."
---

## Overview

JG Inmobiliaria representa sofisticación, solidez y vanguardia arquitectónica. Su estilo visual fusiona el minimalismo arquitectónico contemporáneo con acentos cálidos y estructurados, transmitiendo exclusividad y transparencia en el mercado inmobiliario de alta gama en Medellín (El Poblado, Llanogrande, Laureles) y Bogotá (Rosales, Chicó, Santa Ana). La interfaz destaca los espacios mediante proporciones generosas, contrastes impecables, visualización 3D inmersiva y herramientas interactivas de alta precisión.

## Colors

La paleta cromática utiliza un azul marino pizarra arquitectónico profundo como color primario, equilibrado con tonos cálidos de fondo arena suave y un elegante acento terracota/ámbar dorado que resalta oportunidades, precios y llamados a la acción sin saturar la experiencia.

- **Primary:** Azul pizarra de noche profunda que transmite confianza institucional, elegancia y sobriedad.
- **Accent:** Terracota cálido dorado para resaltar propiedades destacadas, filtros activos y cotizaciones.
- **Secondary:** Carbón neutro para tipografía estructural y detalles sutiles.

```yaml
colors:
  accent: "#B45309"
  on-accent: "#FFFFFF"
  light:
    primary: "#0F172A"
    on-primary: "#FFFFFF"
    primary-container: "#F1F5F9"
    on-primary-container: "#0F172A"
    surface: "#FAFAF9"
    on-surface: "#1C1917"
    surface-variant: "#F5F5F4"
    on-surface-variant: "#44403C"
    outline: "#CBD5E1"
    outline-variant: "#E2E8F0"
  dark:
    primary: "#F8FAFC"
    on-primary: "#0F172A"
    primary-container: "#1E293B"
    on-primary-container: "#F8FAFC"
    surface: "#0B0F19"
    on-surface: "#F1F5F9"
    surface-variant: "#1E293B"
    on-surface-variant: "#94A3B8"
    outline: "#334155"
    outline-variant: "#1E293B"
```

## Typography

Utilizamos una estrategia tipográfica refinada: **Playfair Display** para titulares y números destacados de proyectos, aportando el carácter editorial de la arquitectura de lujo, combinada con **Raleway** para textos descriptivos, filtros, datos técnicos y formularios interactivos.

```yaml
typography:
  display-lg:
    fontFamily: "Playfair Display"
    fontSize: 48px
    fontWeight: 700
    lineHeight: 56px
    letterSpacing: -0.5px
  display-lg-mobile:
    fontFamily: "Playfair Display"
    fontSize: 32px
    fontWeight: 700
    lineHeight: 40px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: "Playfair Display"
    fontSize: 36px
    fontWeight: 600
    lineHeight: 44px
    letterSpacing: -0.25px
  headline-lg-mobile:
    fontFamily: "Playfair Display"
    fontSize: 28px
    fontWeight: 600
    lineHeight: 36px
  headline-md:
    fontFamily: "Playfair Display"
    fontSize: 24px
    fontWeight: 600
    lineHeight: 32px
  headline-sm:
    fontFamily: "Playfair Display"
    fontSize: 20px
    fontWeight: 600
    lineHeight: 28px
  title-lg:
    fontFamily: "Raleway"
    fontSize: 18px
    fontWeight: 700
    lineHeight: 26px
  title-md:
    fontFamily: "Raleway"
    fontSize: 16px
    fontWeight: 600
    lineHeight: 24px
  body-lg:
    fontFamily: "Raleway"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 26px
  body-md:
    fontFamily: "Raleway"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 22px
  body-sm:
    fontFamily: "Raleway"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 18px
  label-lg:
    fontFamily: "Raleway"
    fontSize: 14px
    fontWeight: 600
    lineHeight: 20px
  label-md:
    fontFamily: "Raleway"
    fontSize: 12px
    fontWeight: 600
    lineHeight: 16px
  label-sm:
    fontFamily: "Raleway"
    fontSize: 11px
    fontWeight: 500
    lineHeight: 14px
```

## Layout & Spacing

El diseño utiliza una cuadrícula fluida en dispositivos móviles y una cuadrícula centrada con ancho máximo de 1360px en pantallas de escritorio. La jerarquía se sostiene en un ritmo modular estricto de 8px (con pasos de 4px para microajustes).

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 16px
  gutter-lg: 24px
  gutter-xl: 32px
  section: 64px
  page-margin: 24px
```

## Elevation & Depth

La jerarquía visual se resuelve primordialmente mediante delimitación sutil, superficies apiladas en tono arena claro (`#FAFAF9` a `#FFFFFF`), y sombras ambientales hiperdifuminadas y de baja opacidad inspiradas en la luz solar natural sobre muros estucados. Se evitan sombras duras o bordes pesados.

## Shapes

Líneas limpias y esquinas suavizadas con discreción (radios contenidos entre 8px y 16px), que recuerdan los marcos de ventanería moderna y acabados arquitectónicos contemporáneos.

```yaml
rounded:
  sm: 6px
  DEFAULT: 8px
  md: 12px
  lg: 16px
  xl: 24px
  full: 9999px
```

## Motion & Micro-interaction

Las transiciones son fluidas y sobrias, emulando la sensación de un recorrido virtual de lujo. Las animaciones en 3D responden de manera suave a la posición del cursor o scroll sin generar fatiga visual.

```yaml
motion:
  state-change:
    duration: 120ms
    delay: 0ms
    timingFunction: ease-out
  surface-enter:
    duration: 280ms
    delay: 0ms
    timingFunction: cubic-bezier(0.16, 1, 0.3, 1)
  surface-exit:
    duration: 180ms
    delay: 0ms
    timingFunction: cubic-bezier(0.4, 0, 0.2, 1)
```

## Voice & Content Strategy

El tono de JG Inmobiliaria es consultivo, experto, impecable y cercano. Habla con precisión sobre valores de metro cuadrado, plusvalía, amenidades de lujo y sectores consolidados de Medellín y Bogotá. Los llamados a la acción utilizan verbos directos y transparentes ("Cotizar inversión", "Agendar visita privada", "Filtrar propiedades").

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Badge** → `@components/badge.html`: `badge-numeric`, `badge-dot`
- **Button** → `@components/button.html`: `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html`: `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Input Field** → `@components/input-field.html`: `input-field-text`, `input-field-icon`
